#pragma once
#include<string>
using namespace std;

class Book
{
private:
	int Id;
	char Name [50],Author [20];
	double Price;
public:
	Book();
	Book(int, char[], char[], double);
	~Book();
	void setid(int);
	void setname(char[]);
	void setauthor(char[]);
	void setprice(double);
	int getid();
	string getname() const;
	string getauthor();
	double getprice() const;
	static bool compareName(const Book & b1,const Book & b2)
	{
		return b1.getname() < b2.getname();
	}
	static bool comparePrice(const Book & b1, const Book & b2)
	{
		return b1.getprice() < b2.getprice();
	}
	friend ostream& operator<<(ostream& os, const Book& b)
	{
		os << "Book Id : " << b.Id << "\nBook Name : " << b.Name << "\nBook Author's name : " << b.Author << "\nBook Price : " << b.Price << endl;
		return os;
	}
};

