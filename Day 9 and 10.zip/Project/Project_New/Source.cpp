#include "Book.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

#define FILE_NAME "book_data"

void AddBook()
{
	int id;
	char name[50], author[20];
	double price;
	cout << "Enter the book's id : ";
	cin >> id;
	cout << "Enter the book's name : ";
	cin.ignore();
	cin.getline(name, 50);
	cout << "Enter the book author's name : ";
	cin.getline(author, 20);
	cout << "Enter the book's price : ";
	cin >> price;
	Book b(id, name, author, price);
	ofstream WriteToFile(FILE_NAME, ios::out | ios::app | ios::binary);
	WriteToFile.write((char *)&b, sizeof(Book));
	WriteToFile.close();
	cout << endl << "Book has been succesfully added to the " << FILE_NAME << "file." << endl << endl;
}

void DisplayVector(vector<Book> VectorB)
{
	vector<Book>::iterator ItrBook;
	for (ItrBook = VectorB.begin(); ItrBook != VectorB.end(); ItrBook++)
	{
		cout << *ItrBook << endl;
	}
}

void DisplayBook()
{
	ifstream ReadFile(FILE_NAME, ios::in | ios::binary);
	Book b;
	vector<Book> BookVector;
	while (!ReadFile.eof())
	{
		ReadFile.read((char *)&b, sizeof(Book));
		if (ReadFile.eof())
		{
			break;
		}
		BookVector.push_back(b);
	}
	int i;
	cout << "\n*-*- Display Sub-Menu -*-*\n1 - Display sorted by Name\n2 - Display sorted by Price" << endl;
	cout << "Choose a option" << endl;
	cin >> i;
	if (i == 1)
	{
		sort(BookVector.begin(), BookVector.end(), Book::compareName);
		cout << endl << "Displaying books sorted by name : " << endl;
		DisplayVector(BookVector);

	}
	else if (i == 2)
	{
		sort(BookVector.begin(), BookVector.end(), Book::comparePrice);
		cout << endl << "Displaying books sorted by price : " << endl;
		DisplayVector(BookVector);
	}
	else
	{
		cout << "Invalid Input ." << endl;
	}
	ReadFile.close();
}

void SearchBook(int id)
{
	ifstream ReadFile(FILE_NAME, ios::in | ios::binary);
	Book b;
	vector<Book> BookVector;
	while (!ReadFile.eof())
	{
		ReadFile.read((char *)&b, sizeof(Book));
		if (ReadFile.eof())
		{
			break;
		}
		BookVector.push_back(b);
	}
	vector<Book>::iterator ItrBook;
	int search, flag = 0;
	for (ItrBook = BookVector.begin(); ItrBook != BookVector.end(); ItrBook++)
	{
		search = ItrBook->getid();
		if (search == id)
		{
			cout << "\nThe details of the Book with id : " << id << " are as follows : " << endl;
			cout << *ItrBook;
			flag = 1;
		}
	}

	if (flag == 0)
	{
		cout << "There is no book with id : " << id << endl << endl;
	}

	ReadFile.close();
}

int main()
{
	int ch = 0;
	do
	{
		fstream File(FILE_NAME, ios::in | ios::out | ios::binary);
		File.close();
		int choice;
		cout << "*-*-*-*-*--*-*-*-*-*" << endl << endl;
		cout << "Main Menu : \n1 - Add a Book\n2 - Display Books\n3 - Search for a book" << endl;
		cin >> choice;
		switch (choice)
		{
		case 1:AddBook(); 
			break;
		case 2:DisplayBook();
			break;
		case 3:int i;
			cout << "Enter the id of th book you want to search : ";
			cin >> i;
			SearchBook(i);
			break;
		default:cout << "Invalid Input. Exiting Back to Main menu" << endl;
			break;
		}

		cout << "\nDo you want to continue ?\nEnter 1 to continue or 0 to exit" << endl;
		cin >> ch;
		if (ch != 1 && ch != 0)
		{
			cout << "Invalid Input!! Exiting " << endl;
			exit(0);
		}

	} while (ch == 1);

	return 0;
}