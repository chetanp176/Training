// Dll_Project.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "MathFunc_using_dll.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	MathFunc_using_dll obj;

	cout << obj.Add(10, 30) << endl;

	cout << obj.Sub(30, 10) << endl;

	return 0;
}

