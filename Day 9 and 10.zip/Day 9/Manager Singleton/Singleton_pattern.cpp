// Singleton_pattern.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Manager.h"


int _tmain(int argc, _TCHAR* argv[])
{
	Manager *p = Manager::getMgr();

	p->setid(10);
	p->setname("Abc");

	cout << p->getid() << endl;
	cout << p->getname() << endl;

	Manager *q = Manager::getMgr();

	q->setid(20);
	q->setname("Xyx");

	cout << q->getid() << endl;
	cout << q->getname() << endl;

	return 0;
}

