#pragma once
#include <string>
using namespace std;
class Manager
{
private:
	Manager();
	static Manager *m;
	static int count;
	int id;
	string name;
public:
	~Manager();
	static Manager* getMgr();
	void setid(int);
	void setname(string);
	int getid();
	string getname();
};

