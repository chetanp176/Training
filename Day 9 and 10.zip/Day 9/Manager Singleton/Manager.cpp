#include "stdafx.h"
#include "Manager.h"

int Manager::count = 0;

Manager* Manager::m = NULL;

Manager::Manager()
{
}


Manager::~Manager()
{
}

Manager * Manager::getMgr()
{
	if (count == 0)
	{
		m = new Manager();
		count++;
	}
	return m;
}
void Manager::setid(int i)
{
	this->id = i;
}

void Manager::setname(string n)
{
	this->name = n;
}

int Manager::getid()
{
	return id;
}

string Manager::getname()
{
	return name;
}