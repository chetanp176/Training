#pragma once
class MathFunc_using_dll
{
public:
	MathFunc_using_dll();
	~MathFunc_using_dll();
	int Add(int, int);
	int Sub(int, int);
};

