// CLienT_APP.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "D:\Day_9\Static_Link_Library\MathFunc.h"

int _tmain(int argc, _TCHAR* argv[])
{
	MathFunc m;
	int x;
	x = m.Add(10, 20);

	cout << x << endl;

	return 0;
}

