#include <iostream>
#include <string>
#include <MathFunc_using_dll.h>

using namespace std;

int main()
{
	MathFunc_using_dll obj;

	cout << obj.Add(10, 30) << endl;

	cout << obj.Sub(30, 10) << endl;

	return 0;

}

