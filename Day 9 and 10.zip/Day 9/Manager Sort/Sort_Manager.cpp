// Sort_Manager.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Manager.h"
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

bool compareId(Manager &s1, Manager &s2)
{
	return s1.getid() < s2.getid();
}

int compareName(Manager &s1, Manager &s2)
{
	return s1.getname() < s2.getname();
}

bool compareSalary(Manager &s1, Manager &s2)
{
	return s1.getsalary() < s2.getsalary();
}

Manager ReadManager()
{
	int id;
	char name[20];
	double salary;
	cout << "Enter Manager Id : ";
	cin >> id;
	cout << "Enter Manager Name : ";
	cin >> name;
	cout << "Enter Manager Salary : ";
	cin >> salary;
	Manager m(id, name, salary);
	return m;
}


int _tmain(int argc, _TCHAR* argv[])
{
	vector<Manager>  MgrVector;
	int n = 2;
	for (int i = 0; i < n; i++)
	{
		Manager m = ReadManager();
		MgrVector.push_back(m);
	}

	cout << "Displaying Manager objects from vector" << endl;

	vector<Manager>::iterator MgrItr;
	for (MgrItr = MgrVector.begin(); MgrItr != MgrVector.end(); MgrItr++)
	{
		cout << *MgrItr << endl;
	}

	int ch;
	cout << "On what basis do you want to sort " << endl;
	cout << "1 - Id\n2 - Name\n3 - Salary" << endl;
	cin >> ch;

	if (ch == 1)
	{
		cout << "Sorting based on Id : " << endl;
		sort(MgrVector.begin(), MgrVector.end(), compareId);
	}
	else if (ch == 2)
	{
		cout << "Sorting based on Name : " << endl;
		sort(MgrVector.begin(), MgrVector.end(), compareName);
	}
	else if (ch == 3)
	{
		cout << "Sorting based on Salary : " << endl;
		sort(MgrVector.begin(), MgrVector.end(), compareSalary);
	}
	else
	{
		cout << "Invalid Input. Exiting" << endl;
		exit(0);
	}

	cout << "Displaying after sorting the vector" << endl;
	for (MgrItr = MgrVector.begin(); MgrItr != MgrVector.end(); MgrItr++)
	{
		cout << *MgrItr << endl;
	}

	return 0;
}

