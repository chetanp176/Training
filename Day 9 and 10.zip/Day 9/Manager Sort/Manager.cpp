#include "stdafx.h"
#include "Manager.h"
#include <iostream>

Manager::Manager()
{
}

Manager::Manager(int i, char n[20], double s)
{
	this->id = i;
	strcpy_s(this->name, n);
	this->salary = s;
}

Manager::~Manager()
{
}

void Manager::setid(int i)
{
	this->id = i;
}

void Manager::setname(char arr[20])
{
	strcpy_s(this->name, arr);
}

void Manager::setsalary(double s)
{
	this->salary = s;
}

int Manager::getid() const
{
	return id;
}

string Manager::getname() const
{
	return string(name);
}

double Manager::getsalary() const
{
	return salary;
}

