#pragma once
#include <string>
using namespace std;
class Manager
{
private:
	int id;
	char name[20];
	double salary;
public:
	Manager();
	Manager(int, char[], double);
	~Manager();
	void setid(int);
	void setname(char[]);
	void setsalary(double);
	int getid() const;
	string getname() const;
	double getsalary() const;
	friend ostream& operator<<(ostream& os, const Manager& S)
	{
		os << "Id : " << S.id << "\nName : " << S.name << "\nSalary : " << S.salary << endl;
		return os;
	}
};

