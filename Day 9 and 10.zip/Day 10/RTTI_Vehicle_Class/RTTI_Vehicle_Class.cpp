// RTTI_Vehicle_Class.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include<string>

using namespace std;

#pragma region Vehicle

class Vehicle
{
private:
	int YearOfManufacture;
	string ModelName;

public:
	Vehicle();
	Vehicle(int, string);
	void setYOM(int);
	void setMName(string);
	int getYOM();
	string getMName();
	void virtual Start() = 0;
	void virtual Stop() = 0;
	void virtual toString();
};

Vehicle::Vehicle()
{

}

Vehicle::Vehicle(int y, string n)
{
	this->YearOfManufacture = y;
	this->ModelName = n;
}

void Vehicle::setYOM(int y)
{
	YearOfManufacture = y;
}

void Vehicle::setMName(string n)
{
	ModelName = n;
}

int Vehicle::getYOM()
{
	return YearOfManufacture;
}

string Vehicle::getMName()
{
	return ModelName;
}

void Vehicle::toString()
{
	cout << " Model Name : " << ModelName << endl;
	cout << " Year of Manufacture : " << YearOfManufacture << endl;
}

#pragma endregion

#pragma region Car

class Car : public Vehicle
{
private:
	int SeatCapacity;
public:
	Car();
	Car(int s, int y, string n) :Vehicle(y, n)
	{
		this->SeatCapacity = s;
	}
	void setSCap(int);
	int getSCap();
	void Start();
	void Stop();
	void toString();
};

Car::Car()
{
}

void Car::setSCap(int s)
{
	SeatCapacity = s;
}

int Car::getSCap()
{
	return SeatCapacity;
}

void Car::Start()
{
	cout << this->getMName() << " Car has started " << endl;
}

void Car::Stop()
{
	cout << this->getMName() << " Car has stopped" << endl;
}

void Car::toString()
{
	cout << " Model Name : " << this->getMName() << endl;
	cout << " Year of Manufacture : " << this->getYOM() << endl;
	cout << " Seat Capacity : " << this->getSCap() << endl;
}

#pragma endregion

#pragma region Truck

class Truck : public Vehicle
{
private:
	int MaxLoadCapacity;

public:
	Truck();
	Truck(int m, int y, string n) :Vehicle(y, n)
	{
		this->MaxLoadCapacity = m;
	}
	void setMCap(int);
	int getMCap();
	void Start();
	void Stop();
	void toString();

};

Truck::Truck()
{
}

void Truck::setMCap(int m)
{
	MaxLoadCapacity = m;
}

int Truck::getMCap()
{
	return MaxLoadCapacity;
}

void Truck::Start()
{
	cout << this->getMName() << " Truck has started" << endl;
}

void Truck::Stop()
{
	cout << this->getMName() << " Truck has stopped" << endl;
}

void Truck::toString()
{
	cout << " Model Name : " << this->getMName() << endl;
	cout << " Year of Manufacture : " << this->getYOM() << endl;
	cout << " Max Load Capacity : " << this->getMCap() << endl;
}

#pragma endregion

Vehicle * CreateVehicle()
{
	int r = rand() % 2;
	if (r == 0)
	{
		return new Car();
	}
	else
	{
		return new Truck();
	}
}


int _tmain(int argc, _TCHAR* argv[])
{
	/*Vehicle *v1 = new Car();
	Vehicle *v2 = new Truck();

	cout << typeid(*v1).name() << endl;
	cout << typeid(*v2).name() << endl;*/

	int n, y=0, z=0;
	cout << "Please enter the no of vehicle you want to add" << endl;
	cin >> n;
	const int x = n;
	Vehicle **Ptr = new Vehicle*[x];

	for (int i = 0; i < n; i++)
	{
		Ptr[i] = CreateVehicle();
	}

	for (int i = 0; i < n; i++)
	{
		//can also use dynamic cast
		//check it
		if (typeid(*Ptr[i]) == typeid(Car))
		{
			y++;
		}
		else if (typeid(*Ptr[i]) == typeid(Truck))
		{
			z++;
		}
	}

	cout << y << " cars has been created " << endl;
	cout << z << " trucks has been created " << endl;


	/*for (int i = 0; i < n; i++)
	{
		int choice;
		cout << "1 - Car\n2- Truck" << endl;
		cout << "Choose what you want to add : ";
		cin >> choice;
		if (choice >= 1 && choice <= 2)
		{
			if (choice == 1)
			{
				int YOM, SeatCap;
				string MName;
				cout << "Please enter year of manufacture : ";
				cin >> YOM;
				cout << "Please enter Model Name : ";
				cin.ignore();
				getline(cin, MName);
				cout << "Please enter seating capacity : ";
				cin >> SeatCap;
				Ptr[i] = new Car(SeatCap, YOM, MName);
			}
			else if (choice == 2)
			{
				int YOM, MaxCap;
				string MName;
				cout << "Please enter year of manufacture : ";
				cin >> YOM;
				cout << "Please enter Model Name : ";
				cin.ignore();
				getline(cin, MName);
				cout << "Please enter Max load capacity : ";
				cin >> MaxCap;
				Ptr[i] = new Truck(MaxCap, YOM, MName);
			}
		}
		else
		{
			cout << "invalid input" << endl;
		}
	}*/

	/*for (int i = 0; i < n; i++)
	{
		if (typeid(*Ptr[i]) == typeid(Car))
		{
			Ptr[i]->
		}
	}*/

	/*for (int i = 0; i < n; i++)
	{
		Ptr[i]->Start();
	}

	for (int i = 0; i < n; i++)
	{
		Ptr[i]->Stop();
	}

	for (int i = 0; i < n; i++)
	{
		delete Ptr[i];
	}

	delete[]Ptr;*/

	return 0;
}
