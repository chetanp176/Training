// RuntTTI.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

class Student
{
public:
	Student();
	~Student();

private:

};

Student::Student()
{
}

Student::~Student()
{
}

int main()
{
	Student *s = new Student();

	cout << typeid(s).name() << endl;

	return 0;
}
