// Pointers.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int i = 10;
	int *p = &i;
	int **q = &p;

	cout << "i = " << i << ", &i = " << &i << endl;

	cout << "i = " << i << ", &i = " << &i << endl;

	cout << "i = " << i << ", &i = " << &i << endl;

	cout << "i = " << i << ", &i = " << &i << endl;
	return 0;
}

