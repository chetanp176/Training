// Loop.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int n;
	string var;
	cout << "Please enter the number of which you want the table" << endl;
	//getline(cin, var);
	//n = stoi(var);
	cin >> n;
	if (n >= 0)
	{
		for (int i = 1; i <= 10; i++)
		{
			cout << setw(2);
			cout << n;
			cout << " x ";
			cout << setw(2);
			cout << i;
			cout << " = ";
			cout << setw(3);
			cout << n*i << endl;
		}
	}
	else
	{
		cout << "Invalid Input" << endl;
	}
	getchar();

	return 0;
}

