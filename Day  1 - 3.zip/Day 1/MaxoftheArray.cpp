// Store5numinArray.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <iomanip>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int arr[5], max = 0;
	int n = 5;
	int *p = arr;
	//if address
	//int *p = &arr[0];
	cout << "Please enter 5 numbers" << endl;

	for (int i = 0; i < n; i++)
	{
		int j;
		cin >> j;
		while (j<0)
		{
			cout << "Please enter only positive number" << endl;
			cin >> j;
		}
		arr[i] = j;
	}
	cout << "The array elements are as follows" << endl;
	
	//printing traditionally
	/*for (int i = 0; i < n; i++)
	{
		cout << setw(3) << arr[i] << endl; //<< " at " << &arr[i] <<endl;
		if (arr[i]>max)
		{
			max = arr[i];
		}
	}*/
	//

	cout << "using *a" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << *arr << endl;
	}

	//printing using pointer

	cout << "using p[i]" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << p[i] << endl;
	}
	cout << "using *p" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << *p << endl;
		if (*p > max)
		{
			max = *p;
		}
		p++;
	}

	cout << endl << "The maximum of the array is " << max << endl;

	getchar();

	return 0;
}