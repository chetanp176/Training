// Addof2 Arrays.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int n = 5;
	int a[5], b[5], c[5];
	int *p = a;
	int *q = b;
	int *r = c;

	cout << "Enter 5 Numbers for 1st array" << endl;
	for (int i = 0; i < n; i++)
	{
		cin >> *p;
		//a[i] = *p;
		p++;
	}

	cout << "Enter 5 Numbers for 2nd array" << endl;
	for (int i = 0; i < n; i++)
	{
		cin >> *q;
		//b[i] = *q;
		q++;
	}

	cout << "First array elements are" << endl;
	p = a;
	for (int i = 0; i < n; i++)
	{
		cout << *p << endl;
		p++;
	}

	cout << "Second array elements are" << endl;
	q = b;
	for (int i = 0; i < n; i++)
	{
		cout << *q << endl;
		q++;
	}

	p = a;
	q = b;
	for (int i = 0; i < n; i++)
	{
		*r = *p + *q;
		//c[i] = *r;
		p++;
		q++;
		r++;
	}

	cout << endl << "The sum of two arrays is " << endl;
	r = c;
	for (int i = 0; i < n; i++)
	{
		cout << *r << endl;
		r++;
	}

	return 0;
}

