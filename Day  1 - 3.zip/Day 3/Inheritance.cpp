// Imheritance.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

class A
{
public:
	void virtual show();
	void process();
};

void A::show()
{
	cout << "A's show method" << endl;
}

void A::process()
{
	cout << "A's process method" << endl;
}

class B : public A
{
public:
	void show();
};

void B::show()
{
	cout << "B's show method" << endl;
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Static memory allocation of Class A object" << endl;
	A obj1;
	obj1.show();
	obj1.process();

	cout << "Dynamic memory allocation of Class A object" << endl;
	A *q = new A();
	q->show();
	q->process();

	cout << "Static memory allocation of Class B object" << endl;
	B obj2;
	obj2.show();
	obj2.process();

	cout << "Dynamic memory allocation of Class B object" << endl;
	B *p = new B();
	p->show();
	p->process();

	A *r = new B();
	r->show();
	r->process();

	delete p;

	delete q;

	delete r;

	return 0;
}

