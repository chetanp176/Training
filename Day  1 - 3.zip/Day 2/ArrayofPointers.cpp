// ArrayofPointers.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

int add(int x, int y)
{
	return x + y;
}

int sub(int x, int y)
{
	return x - y;
}

int mul(int x, int y)
{
	return x * y;
}

//int div(int x, int y)
//{
//	int j;
//	j = x / y;
//	return j;
//}

int _tmain(int argc, _TCHAR* argv[])
{
	int choice;
	int(*p[4])(int, int);
	p[0] = add;
	p[1] = sub;
	p[2] = mul;
	//p[3] = div;

	cout << "1 - Addition" << endl << "2 - Subtraction" << endl << "3 - Multiplication" << endl << "4 - Division" << endl;

	cout << "Please enter your choice : ";

	cin >> choice;

	if (choice >= 1 && choice <= 4)
	{
		int a, b, c;
		cout << "Please enter first number : ";
		cin >> a;
		cout << endl << "Please enter second number : ";
		cin >> b;
		c = p[choice - 1](a, b);
		cout << "The result is " << c << endl;
	}
	else
	{
		cout << "Invalid Input" << endl;
	}

	getchar();

	return 0;
}

