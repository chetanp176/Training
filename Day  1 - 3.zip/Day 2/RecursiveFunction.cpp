// RecursiveFunction.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

void rec(int n)
{
	/*static int i = 1;
	if (n > 0)
	{
		cout << n - (n - i) << endl;
		i++;
	}
	rec(n - 1);*/
	
	// Printing in Opposite order From n to 1
	cout << n << endl;
	if (n > 1)
	{
		rec(n - 1);
	}

	// Printing in Correct order From 1 to n
	/*if (n > 1)
	{
		rec(n - 1);
	}
	cout << n << endl;*/

}


int _tmain(int argc, _TCHAR* argv[])
{
	int n;

	cout << "Please enter the number limit n " << endl;

	cin >> n;

	rec(n);

	return 0;
}

