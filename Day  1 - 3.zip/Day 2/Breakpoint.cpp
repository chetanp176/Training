// Breakpoint.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

int add(int x, int y)
{
	cout << "Inside the function Add(..)" << endl;
	int res = x + y;
	return res;
}

int _tmain(int argc, _TCHAR* argv[])
{

	int r = add(10, 20);

	cout << endl << "The addition is " << r << endl;

	getchar();
	return 0;
}

