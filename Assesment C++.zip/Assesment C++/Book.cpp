#include "Book.h"


Book::Book()
{
}


Book::~Book()
{
}

Book::Book(int i, char n[20], char a[20], double p)
{
	this->Id = i;
	strcpy_s(this->Name, n);
	strcpy_s(this->Author, a);
	this->Price = p;
}

void Book::setid(int i)
{
	this->Id = i;
}

void Book::setname(char n[20])
{
	strcpy_s(this->Name, n);
}

void Book::setauthor(char a[20])
{
	strcpy_s(this->Author, a);
}

void Book::setprice(double p)
{
	this->Price = p;
}

int Book::getid()
{
	return Id;
}

string Book::getname() const
{
	return string(Name);
}

string Book::getauthor()
{
	return string(Author);
}

double Book::getprice() const
{
	return Price;
}
