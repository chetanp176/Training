// ConstructorDestructor.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

class Base
{
public:
	Base();
	virtual ~Base();
};

Base::Base()
{
	cout << "Base Class Constructor" << endl;
}

Base::~Base()
{
	cout << "Base Class Destructor" << endl;
}

class Derived : public Base
{
public:
	Derived();
	~Derived();

};

Derived::Derived()
{
	cout << "Derived Class Constructor" << endl;
}

Derived::~Derived()
{
	cout << "Derived Class Destructor" << endl;
}


int _tmain(int argc, _TCHAR* argv[])
{
	Base *p = new Derived();

	delete p;

	return 0;
}

