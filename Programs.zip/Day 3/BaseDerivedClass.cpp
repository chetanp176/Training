// BaseDerivedClass.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

class Person
{
public:
	//Default Constructor
	Person();
	//Parametrised Constructor
	Person(int);
	void setage(int);
	int getage();

private:
	int age;

};

Person::Person()
{
}

Person::Person( int a)
{
	this->age = a;
}

void Person::setage(int a)
{
	age = a;
}

int Person::getage()
{
	return age;
}




class Student : public Person
{
public:
	Student(int,string,int);
	void setroll(int);
	void setname(string);
	int getroll();
	string getname();
	void toString();

private:
	int roll;
	string name;

};

Student::Student(int r, string n,int a) //This Method //:Person(a)
{
	this->roll = r;
	this->name = n;
	//Or
	//This method
	this->setage(a);
}

void Student::setroll(int a)
{
	roll = a;
}

void Student::setname(string n)
{
	name = n;
}

int Student::getroll()
{
	return roll;
}

string Student::getname()
{
	return name;
}

void Student::toString()
{
	cout << "Roll no : " << roll << endl;
	cout << "Name : " << name << endl;
	cout << "Age : " << this->getage() <<endl;
}


int _tmain(int argc, _TCHAR* argv[])
{
	Student s(10, "Name", 25);

	s.toString();

	return 0;
}

