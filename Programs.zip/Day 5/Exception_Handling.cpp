// Exception_Handling.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	try
	{
		cout << "Hello World" << endl;
		throw - 1.235;
	}
	catch (int x)
	{
		cout << "Error occured value : " << x << endl;
	}

	getchar();

	return 0;
}

