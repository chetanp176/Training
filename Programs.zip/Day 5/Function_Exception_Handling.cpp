// Function_Exception_Handling.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

void C()
{
	throw 10;
}

void B()
{
	C();
}

void A()
{
	try
	{
		B();
	}
	catch (int x)
	{
		cout << "Handled in A Value : " << x << endl;
		throw;
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	try
	{
		A();
	}
	catch (int z)
	{
		cout << "Handled in main value : " << z << endl;
	}
	return 0;
}

