// PassByMehods.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

//Pass By value
//void add(int x, int y)
//{
//	cout << x + y << endl;
//	x = 0;
//	y = 0;
//}

//Pass By address
//void add(int *p, int *q)
//{
//	cout << *p + *q << endl;
//	*p = 0;
//	*q = 0;
//}

//Pass by reference
void add(int& x, int& y)
{
	cout << x + y << endl;
	x = 0;
	y = 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	int a = 5; int b = 10;

	// pass by value
	//add(a, b);

	//pass by address
	//add(&a, &b);

	//pass by reference
	add (a, b);

	//Values are not modified in Pass by value Method
	//Values are modified in Pass by address Method
	//Values are modfied in Pass by reference Method
	cout << "a = " << a << endl <<"b = " << b << endl;
	getchar();

	return 0;
}

