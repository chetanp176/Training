// SimpleClass.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

class Student
{
private:
	int roll;
	string name;
public:
	void toString();
	void Setroll(int r);
	void Setname(string n);
	int Getroll();
	string Getname();

};
int Student::Getroll()
{
	return roll;
}

string Student::Getname()
{
	return name;
}

void Student::Setroll(int r)
{
	roll = r;
}

void Student::Setname(string n)
{
	name = n;
}

void Student::toString()
{
	cout << "Roll : " << roll << "\nName :" << name << endl;
}

int _tmain(int argc, _TCHAR* argv[])
{
	Student Studarr[3];
	int rollno;
	string sname;

	for (int i = 0; i < 3; i++)
	{
		cout << "Please enter the roll number" << endl;
		cin >> rollno;
		cout << "Please enter the name" << endl;
		cin >> sname;
		Studarr[i].Setroll(rollno);
		Studarr[i].Setname(sname);
	}

	cout << endl << "The student details are :" << endl;
	for (int i = 0; i < 3; i++)
	{
		Studarr[i].toString();
	}
	getchar();
	return 0;
}

