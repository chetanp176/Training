#ifdef MATHLIBRARY_EXPORTS  
#define MATHLIBRARY_API __declspec(dllexport)   
#else  
#define MATHLIBRARY_API __declspec(dllimport)   
#endif 

class MathFunc_using_dll
{
public:
	__declspec(dllexport) int Add(int, int);
	MATHLIBRARY_API int Sub(int, int);
};

