#include "MathFunc_using_dll.h"
#include <iostream>
using namespace std;


int MathFunc_using_dll::Add(int a, int b)
{
	return a + b;
}

int MathFunc_using_dll::Sub(int a, int b)
{
	return a - b;
}