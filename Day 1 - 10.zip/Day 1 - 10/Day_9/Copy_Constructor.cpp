// Copy_Constructor.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Student.h"

int _tmain(int argc, _TCHAR* argv[])
{
	Student S1(10, "Chetan");
	Student S2;
	S2 = S1;
	Student S3 = S1;
	Student S4(S1);

	S1.toString();

	S2.toString();

	S3.toString();

	S4.toString();

	return 0;
}

