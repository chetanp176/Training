#include <iostream>

using namespace std;

class MathFunc
{
private:
public:
	MathFunc();
	~MathFunc();
	int Add(int, int);
	int Sub(int, int);
};