#include "MathFunc.h"

MathFunc::MathFunc()
{
}

MathFunc::~MathFunc()
{
}
int MathFunc::Add(int i, int j)
{
	return i + j;
}
int MathFunc::Sub(int i, int j)
{
	return i - j;
}