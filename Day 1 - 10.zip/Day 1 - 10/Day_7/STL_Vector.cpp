// STL_Vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include < iostream >
#include <algorithm>
#include <vector> 

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	vector<int> v;
	int n = 5;
	int x;
	cout << "Enter 5 elements : " << endl;
	for (int i = 0; i < n; i++)
	{
		cin >> x;
		v.push_back(x);
	}

	cout << "Displaying vector elements : " << endl;

	for (int i = 0; i < n; i++)
	{
		cout << v[i] << endl;
	}

	cout << "Sorting elements" << endl;

	sort(v.begin(), v.end());

	cout << "Displaying vector elements after sorting : " << endl;

	for (int i = 0; i < n; i++)
	{
		cout << v[i] << endl;
	}

	return 0;
}

