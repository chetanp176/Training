// FunctionPointers.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;
int add(int x, int y)
{
	return x + y;
}

//Function pointer inside a Function
int process(int c, int d, int (*p)(int, int))
{
	return p(c, d);
}

int _tmain(int argc, _TCHAR* argv[])
{
	int a, b;

	//Function Pointer
	int (*p)(int, int);
	
	//Function Pointer Assignment
	p = add;

	cout << "Please enter first number" << endl;
	cin >> a;
	cout << "Please enter second number" << endl;
	cin >> b;

	cout << "Calling Function using Pointer" << endl;

	int r = p(a, b);

	cout << "The Sum is " << r << endl;

	cout << "Passing the pointer to another function and calling the pointer there" << endl;

	r = process(a, b, p);

	cout << "The Sum is " << r << endl;

	return 0;
}

