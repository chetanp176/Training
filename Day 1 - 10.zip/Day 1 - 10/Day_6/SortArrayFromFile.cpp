// SortArray_FromFile.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

const int x = 6;

void SortArray(int arr[], int n)
{
	int temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n - 1; j++)
		{
			if (arr[i] < arr[j])
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}

}

void ReadIntoArray(string name, int *arr)
{
	ifstream ReadF(name);

	string line;

	int i = 0;
	while (getline(ReadF, line))
	{
		arr[i] = stoi(line);
		i++;
	}

	ReadF.close();
}

void ArrayToFile(int *arr, int n)
{
	ofstream WriteF("sorted.txt", ios::out | ios::app);

	for (int i = 0; i < n; i++)
	{
		WriteF << arr[i] << endl;
	}

	WriteF.close();
}

void ReadFile()
{
	ifstream ReadF("sorted.txt");

	string line;

	while (getline(ReadF,line))
	{
		cout << line << endl;
	}

	ReadF.close();
}

int _tmain(int argc, _TCHAR* argv[])
{
	string name = "data.txt";

	int intarr[x];

	cout << "Reading from data.txt to array " << endl << endl;

	ReadIntoArray(name, intarr);

	cout << "Printing the array " << endl;

	for (int i = 0; i < x; i++)
	{
		cout << intarr[i] << endl;
	}

	cout << endl << "Sorting the array " << endl << endl;

	SortArray(intarr, x);

	cout << "Writing sorted array to sorted.txt" << endl << endl;

	ArrayToFile(intarr, x);

	cout << " Reading from sorted.txt " << endl;

	ReadFile();

	return 0;
}