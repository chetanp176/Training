// Array_to_File.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

const int x = 10;

void Read_array(int *arr, int n)
{
	for (int i = 0; i < n; i++)
	{
		cin >> arr[i];
	}
}

void WriteEven(int n)
{
	ofstream EvenF("Even.txt", ios::out | ios::app);

	EvenF << n << endl;

	EvenF.close();
}

void WriteOdd(int n)
{
	ofstream OddF("Odd.txt", ios::out | ios::app);

	OddF << n << endl;

	OddF.close();
}

void CheckEvenOdd(int *arr, int n)
{
	for (int i = 0; i < n; i++)
	{
		if ((arr[i] % 2) == 0)
		{
			WriteEven(arr[i]);
		}
		else
		{
			WriteOdd(arr[i]);
		}
	}
}


void ReadEven()
{
	ifstream ReadE("Even.txt");

	string line;

	while (getline(ReadE, line))
	{
		cout << line << endl;
	}

	ReadE.close();
}

void ReadOdd()
{
	ifstream ReadO("Odd.txt");

	string line;

	while (getline(ReadO, line))
	{
		cout << line << endl;
	}

	ReadO.close();
}

int _tmain(int argc, _TCHAR* argv[])
{
	int intarr[x];

	cout << "Please enter 10 array elements " << endl;

	Read_array(intarr, x);

	cout << "Checking for even and odd numbers : " << endl;

	CheckEvenOdd(intarr, x);

	cout << "Printing the even text file " << endl;

	ReadEven();

	cout << "Printing the odd text file " << endl;

	ReadOdd();

	return 0;
}

