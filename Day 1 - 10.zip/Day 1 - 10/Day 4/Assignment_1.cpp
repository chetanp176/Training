// Assignment_1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "string"

using namespace std;

class Student
{
private:
	int roll;
	string name;
public:
	static int count;
	Student()
	{
	}
	Student(int,string);
	void setroll(int r)
	{
		roll = r;
	}
	void setname(string n)
	{
		name = n;
	}
	int getroll()
	{
		return roll;
	}
	string getname()
	{
		return name;
	}
	void toString()
	{
		cout << "Roll : " << roll << endl;
		cout << "Name : " << name << endl;
	}
};

int Student::count = 0;

Student::Student(int r,string n)
{
	this->name = n;
	this->roll = r;
}

int _tmain(int argc, _TCHAR* argv[])
{
	Student *p[3];
	int n = 3;
	for (int i = 0; i < n; i++)
	{
		int roll;
		string name;
		cout << "Enter Student's roll" << endl;
		cin >> roll;
		cout << "Enter Student's name" << endl;
		cin.ignore();
		getline(cin, name);
		p[i] = new Student(roll, name);
		Student::count++;
	}

	cout << "The student Details are : " << endl;

	for (int i = 0; i < n; i++)
	{
		p[i]->toString();
	}

	cout << "The number of students are : " << Student::count << endl;

	return 0;
}

