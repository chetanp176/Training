// Template_Max.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

template < class T>
T FindMax(T arr[], int n)
{
	T max = arr[0];
	for (int i = 0; i < n; i++)
	{
		if (arr[i] > max)
		{
			max = arr[i];
		}
	}
	return max;
}

//template < class U>
//void SortArray(U arr[], int n)
//{
//	U temp;
//	for (int i = 0; i < n; i++)
//	{
//		for (int j = 0; j < n-1; j++)
//		{
//			if (arr[i] < arr[j])
//			{
//				temp = arr[i];
//				arr[i] = arr[j];
//				arr[j] = temp;
//			}
//		}
//	}
//
//	cout << endl << "The sorted array is : " << endl;
//
//	for (int i = 0; i < n; i++)
//	{
//		cout << arr[i] << endl;
//	}
//}

template < class U>
void SortArray(U arr[], int n)
{
	U temp;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n - 1; j++)
		{
			if (arr[i] < arr[j])
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}

}


int _tmain(int argc, _TCHAR* argv[])
{
	int a[5];
	a[0] = 5;
	a[1] = 2;
	a[2] = 8;
	a[3] = 4;
	a[4] = 1;

	int n = 5;

	int max = FindMax<int>(a, 5);

	cout << max;

	SortArray<int>(a, 5);

	cout << endl << "The sorted array is : " << endl;

	for (int i = 0; i < n; i++)
	{
		cout << a[i] << endl;
	}

	double b[5];
	b[0] = 10.33;
	b[1] = 12.96;
	b[2] = 08.96;
	b[3] = 11.25;
	b[4] = 05.32;

	double dmax = FindMax<double>(b, 5);

	cout << endl << dmax;

	SortArray<double>(b, 5);

	cout << endl << "The sorted array is : " << endl;

	for (int i = 0; i < n; i++)
	{
		cout << b[i] << endl;
	}


	return 0;
}