// Class-Template.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "string"
#include <iostream>

using namespace std;

template<class T,class U>
class A
{
private:
	T var;
	U uvar;
public:
	A()
	{

	}
	A(T v,U u)
	{
		this->var = v;
		this->uvar = u;
	}
	void setvar(T x)
	{
		var = x;
	}
	T getvar()
	{
		return this->var;
	}
	void setuvar(U u)
	{
		uvar = u;
	}
	U getuvar()
	{
		return this->uvar;
	}
	void toString()
	{
		cout << "var : " << var << endl;
		cout << "uvar : " << uvar << endl;
	}

};

int _tmain(int argc, _TCHAR* argv[])
{
	A<string, int> obj("Name",10);

	obj.toString();

	/*A<int> obj()

	obj.toString();

	A<double> objd(10.56);
*/
	//objd.toString();

	return 0;
}

