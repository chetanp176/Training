// Store5numinArray.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <iomanip>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int arr[5], sum=0;
	int n = 5;

	cout << "Please enter 5 numbers" << endl;

	for (int i = 0; i < n; i++)
	{
		int j;
		cin >> j;
		while (j<0)
		{
			cout << "Please enter only positive number" << endl;
			cin >> j;
		}
		arr[i] = j;
	}
	cout << "The array elements are as follows" << endl;
	for (int i = 0; i <= n; i++)
	{
		cout << setw(3) << arr[i] << endl; //<< " at " << &arr[i] <<endl;
		sum += arr[i];
	}
	cout << "The total of all the elements in the array is " << sum << endl;

	getchar();

	return 0;
}

