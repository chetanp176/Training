// ReadFromUser.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;
int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Please enter your name" << endl;

	string name;

	getline(cin, name);

	cout << "Hello " << name << endl;

	getchar();

	return 0;
}

