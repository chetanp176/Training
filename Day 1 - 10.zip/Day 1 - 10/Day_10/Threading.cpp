// Threading.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <thread>

using namespace std;
void print()
{
	for (int i = 0; i < 10; i++)
	{
		cout << "Hello (print)" << this_thread::get_id() << endl;
		//this_thread::sleep_for(std::chrono::minutes(1));
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	thread t1(print);

	thread t2(print);

	for (int i = 0; i < 10; i++)
	{
		cout << "Hello (main)" << endl;
	}

	t1.join();

	t2.join();

	return 0;
}

