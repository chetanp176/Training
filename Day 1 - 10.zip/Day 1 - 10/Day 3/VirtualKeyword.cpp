// VirtualKeyword.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

class Shape
{
public:
	//void virtual draw();
	//pure virtual function
	void virtual draw() = 0;

	void virtual Print()
	{
		cout << "Parent print method" << endl;
	}

};

//void Shape::draw()
//{
//	cout << "Parent's Draw method" << endl;
//}

class Circle : public Shape
{
public:
	void draw();
	void Print()
	{
		cout << "Circle print method" << endl;
	}
};

void Circle::draw()
{
	cout << "Circle's draw method" << endl;
}

class Rectangle : public Shape
{
public:
	void draw();
};

void Rectangle::draw()
{
	cout << "Rectangle's draw method" << endl;
}

class Triangle : public Shape
{
public:
	void draw();
};

void Triangle::draw()
{
	cout << "Triangle's draw method" << endl;
}

Shape * getshape(int n)
{
	if (n == 1)
	{
		return new Circle();
	}
	else if (n == 2)
	{
		return new Rectangle();
	}
	else
	{
		return new Triangle();
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	int choice;

	cout << "1 - Circle\n2 - Rectangle\n3 - Triangle" << endl;

	cout << "Please choose a shape" << endl;

	cin >> choice;

	if (choice >=1 && choice <=3)
	{
		Shape *s = getshape(choice);
		s->draw();
		s->Print();
	}
	else
	{
		cout << "Invalid Input" << endl;
	}

	return 0;
}

