// STL_Other_Containers_int.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <algorithm>
#include <list> 
#include <map>
#include <set>
#include <string>

using namespace std;

void ListFunc()
{
	list<int> IntL;

	IntL.push_back(54);
	IntL.push_back(459);
	IntL.push_back(32);
	IntL.push_back(68);
	IntL.push_back(89);

	list<int>::iterator IntItr;

	cout << "Printing List " << endl;

	for (IntItr = IntL.begin(); IntItr != IntL.end(); IntItr++)
	{
		cout << *IntItr << endl;
	}

}

void MapFunc()
{
	map<int,string> StrMap;

	StrMap[15] = "abc";
	StrMap[7] = "xyz";
	StrMap[7] = "pqr";

	pair<int, string>p(7, "tuv");

	StrMap.insert(p);

	cout << endl << "Printing Map " << endl;

	map<int, string>::iterator StrItr;

	for (StrItr = StrMap.begin(); StrItr != StrMap.end(); StrItr++)
	{
		cout << "Key : " << (*StrItr).first << " Value : " << (*StrItr).second << endl;
	}

	cout << endl << "Printing Multimap " << endl;

	multimap<int, string> StrMulMap;

	StrMulMap.insert(pair<int, string>(10, "chetan"));
	StrMulMap.insert(pair<int, string>(20, "ravi"));
	StrMulMap.insert(pair<int, string>(30, "Rajath"));
	StrMulMap.insert(pair<int, string>(10, "abhi"));

	multimap<int, string>::iterator StrMulItr;

	for (StrMulItr = StrMulMap.begin(); StrMulItr != StrMulMap.end(); StrMulItr++)
	{
		cout << "Key : " << (*StrMulItr).first << " Value : " << (*StrMulItr).second << endl;
	}

}

void SetFunc()
{
	set<int> IntSet;

	IntSet.insert(10);
	IntSet.insert(20);
	IntSet.insert(30);
	IntSet.insert(10);
	IntSet.insert(30);

	cout << endl << "Printing Set " << endl;

	set<int>::iterator IntItr;

	for (IntItr = IntSet.begin(); IntItr != IntSet.end(); IntItr++)
	{
		cout << "Value : " << *IntItr << endl;
	}

	multiset<int> IntMulSet;

	IntMulSet.insert(10);
	IntMulSet.insert(20);
	IntMulSet.insert(30);
	IntMulSet.insert(10);
	IntMulSet.insert(30);

	cout << endl << "Printing MultiSet " << endl;

	multiset<int>::iterator IntMulItr;

	for (IntMulItr = IntMulSet.begin(); IntMulItr != IntMulSet.end(); IntMulItr++)
	{
		cout << "Value : " << *IntMulItr << endl;
	}

}

int _tmain(int argc, _TCHAR* argv[])
{
	ListFunc();

	MapFunc();

	SetFunc();

	return 0;
}

