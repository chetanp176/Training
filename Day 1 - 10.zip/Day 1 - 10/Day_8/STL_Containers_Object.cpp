// STL_Other_Containers_int.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <algorithm>
#include <list> 
#include <map>
#include <set>
#include <string>

using namespace std;

class Student
{
private:
	int roll;
	char name[20];
public:
	Student();
	Student(int, char[]);
	void setroll(int);
	void setname(char[]);
	int getroll() const;
	string getname() const;
	void toString();
	char getFirst();
	bool operator<(const Student &s2) const
	{
		return this->getroll() < s2.getroll();
	}
	bool operator==(const Student &s2)
	{
		return((this->getroll() == s2.getroll()) && (this->getname() == s2.getname()));
	}
	friend ostream& operator<<(ostream& os, const Student& S)
	{
		os << "Name : " << S.name << "\nRoll : " << S.roll << endl;
		return os;
	}
};


int compareName(Student &s1, Student &s2){
	return s1.getname() < s2.getname();
}


Student::Student()
{
}

Student::Student(int r, char n[20])
{
	this->roll = r;
	strcpy_s(this->name, n);
}

void Student::setroll(int r)
{
	this->roll = r;
}

void Student::setname(char arr[20])
{
	strcpy_s(this->name, arr);
}

int Student::getroll() const
{
	return roll;
}

string Student::getname() const
{
	return string(name);
}

void Student::toString()
{
	cout << "Roll : " << roll << endl;
	cout << "Name : " << name << endl;
}

Student ReadStudent()
{
	int roll;
	char name[20];
	cout << "Enter Student Roll : ";
	cin >> roll;
	cout << "Enter Student Name : ";
	cin >> name;
	Student S(roll, name);
	return S;
}

void ListFunc()
{
	list<Student> StudentL;

	Student S5 = ReadStudent();

	Student S1(10, "abc"), S2(20, "agda"), S3(5, "xyz"), S4(20, "xyz");

	StudentL.push_back(S1);
	StudentL.push_back(S2);
	StudentL.push_back(S3);
	StudentL.push_back(S4);
	StudentL.push_back(S5);

	
	list<Student>::iterator StudentItr;

	cout << "Printing Student List " << endl;

	for (StudentItr = StudentL.begin(); StudentItr != StudentL.end(); StudentItr++)
	{
		cout << *StudentItr << endl;
	}

}

void MapFunc()
{
	map<int, Student> StudentMap;

	Student S1(10, "abc"), S2(20, "agda"), S3(5, "xyz"), S4(20, "xyz");

	StudentMap[1] = S1;
	StudentMap[4] = S2;
	StudentMap[4] = S3;

	pair<int, Student>p(2, S4);

	StudentMap.insert(p);

	cout << endl << "Printing Student Map " << endl;

	map<int, Student>::iterator StudentItr;

	for (StudentItr = StudentMap.begin(); StudentItr != StudentMap.end(); StudentItr++)
	{
		cout << "Key : " << (*StudentItr).first << endl << "Value : " << endl << (*StudentItr).second << endl;
	}


	multimap<int, Student> StdMulMap;

	StdMulMap.insert(pair<int, Student>(10, S1));
	StdMulMap.insert(pair<int, Student>(20, S2));
	StdMulMap.insert(pair<int, Student>(30, S3));
	StdMulMap.insert(pair<int, Student>(10, S4));

	multimap<int, Student>::iterator StdMulItr;

	cout << endl << "Printing Student Multimap " << endl;

	for (StdMulItr = StdMulMap.begin(); StdMulItr != StdMulMap.end(); StdMulItr++)
	{
		cout << "Key : " << (*StdMulItr).first << "\nValue : \n" << (*StdMulItr).second << endl;
	}

}

void SetFunc()
{
	set<Student> StudentSet;
	Student S1(10, "abc"), S2(20, "agda"), S3(5, "xyz"), S4(5, "def");

	StudentSet.insert(S1);
	StudentSet.insert(S2);
	StudentSet.insert(S3);
	StudentSet.insert(S4);

	cout << endl << "Printing Student Set " << endl;

	set<Student>::iterator StudentItr;

	for (StudentItr = StudentSet.begin(); StudentItr != StudentSet.end(); StudentItr++)
	{
		cout << "Value : " << endl << *StudentItr << endl;
	}

	multiset<Student> StudentMulSet;

	StudentMulSet.insert(S1);
	StudentMulSet.insert(S2);
	StudentMulSet.insert(S3);
	StudentMulSet.insert(S4);

	cout << endl << "Printing Student MultiSet " << endl;

	multiset<Student>::iterator StdMulItr;

	for (StdMulItr = StudentMulSet.begin(); StdMulItr != StudentMulSet.end(); StdMulItr++)
	{
		cout << "Value : " << *StdMulItr << endl;
	}

}

int _tmain(int argc, _TCHAR* argv[])
{
	ListFunc();

	MapFunc();

	SetFunc();

	return 0;
}

