// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	vector<int> v;
	vector<int>::iterator it;

	int n = 5;
	int x;
	cout << "Enter 5 elements : " << endl;
	for (int i = 0; i < n; i++)
	{
		cin >> x;
		v.push_back(x);
	}

	cout << "Displaying vector elements" << endl;

	for (it = v.begin(); it != v.end(); it++)
	{
		cout << *it << endl;
	}

	return 0;
}

