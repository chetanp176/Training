// Different_Exception.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

void display()
{
	int ch;
	cin >> ch;
	switch (ch)
	{
	case 1: throw 10;
		break;
	case 2: throw 5.5;
		break;
	case 3: throw "Error";
		break;
	default:
		break;
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	try
	{
		display();
	}
	catch (int x)
	{
		cout << "Error occured value : " << x << endl;
	}
	catch (...)
	{
		cout << "Some Error Occured " << endl;
	}
	return 0;
}

