// Object_Exception.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

class A
{
private:
public:
	A()
	{
	}

};

class B : public A
{
private:
public:
	B()
	{
	}

};


int _tmain(int argc, _TCHAR* argv[])
{
	A a;
	B b;

	try
	{
		throw b;
	}
	catch (A x)
	{
		cout << "Handled by A" << endl;
	}
	catch (B y)
	{
		cout << "Handled by B" << endl;
	}
	return 0;
}

