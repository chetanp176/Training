// Object_to_File.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Student
{
private:
	int roll;
	char name[20];
public:
	Student();
	Student(int, char[]);
	void setroll(int);
	void setname(char[]);
	int getroll();
	string getname();
	void toString();
};

Student::Student()
{
}

Student::Student(int r, char n[20])
{
	this->roll = r;
	strcpy_s(this->name, n);
}

void Student::setroll(int r)
{
	this->roll = r;
}

void Student::setname(char arr[20])
{
	strcpy_s(this->name, arr);
}

int Student::getroll()
{
	return roll;
}

string Student::getname()
{
	return string(name);
}

void Student::toString()
{
	cout << "Roll : " << roll << endl;
	cout << "Name : " << name << endl;
}

void WriteStudent()
{
	ofstream StudentWrite("Student_Data", ios::out | ios::binary | ios::app);
	int roll;
	char name[20];
	cout << "Enter Student Roll : ";
	cin >> roll;
	cout << "Enter Student Name : ";
	cin >> name;
	cout << "Entering the student object into the file : " << endl << endl;
	Student S(roll, name);
	StudentWrite.write((char *)&S, sizeof(Student));
	StudentWrite.close();
}

void ReadStudent()
{
	ifstream StudentRead("Student_Data", ios::in | ios::binary);
	Student R;
	while (!StudentRead.eof())
	{
		StudentRead.read((char *)&R, sizeof(Student));
		if (StudentRead.eof())
		{
			break;
		}
		R.toString();
	}

	StudentRead.close();
}

void ModifySudent(int n)
{

	int newroll;
	char newname[20];
	cout << "Please enter new roll : ";
	cin >> newroll;
	cout << "Please enter new name : ";
	cin >> newname;
	Student New(newroll, newname);
	fstream StudentFile("Student_Data", ios::out | ios::in);
	StudentFile.seekp(((n-1)*(sizeof(Student))), ios::beg);
	cout << StudentFile.tellp();
	StudentFile.write((char*)&New, sizeof(Student));
	StudentFile.close();
}

int _tmain(int argc, _TCHAR* argv[])
{
	/*int n = 2;
	cout << "Enter "<< n <<" Students Data : " << endl;
	for (int i = 0; i < n; i++)
	{
		WriteStudent();
	}*/

	cout << "Reading Student object from file" << endl << endl;
	cout << "The student details taken from the file are : " << endl;
	ReadStudent();

	int ch;
	cout << "Which student data do you want to modify " << endl;
	cin >> ch;
	ModifySudent(ch);

	cout << "Displaying new students data" << endl;
	ReadStudent();

	return 0;
}