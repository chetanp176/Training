// Random_Access_Files.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{

	fstream file("letters.txt", ios::out|ios::in);
	char ch = 'X';

	file.seekp(4, ios::beg);
	file.put(ch);
	file.close();
	return 0;
}

