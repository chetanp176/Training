// Random_Access_Files.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{

	fstream file("letters.txt", ios::in);
	char ch;

	cout << "Printing the 5th character from the file : " << endl;

	file.seekg(0, ios::end);
	int length = file.tellg();
	int n = 5 % length;

	file.seekg(12, ios::beg);
	file.get(ch);
	cout << ch << endl;
	
	for (int i = 1; i < n; i++)
	{
		file.seekg(14, ios::cur);
		file.get(ch);
		cout << ch << endl;
	}

	//Using End of file 

	/*file.seekg(4, ios::beg);
	file.get(ch);
	cout << ch << endl;

	while (file.peek()!=EOF)
	{
		file.seekg(4, ios::cur);
		file.get(ch);
		if (file.peek()== EOF)
		{
			break;
		}
		cout << ch << endl;
	}*/

	return 0;
}