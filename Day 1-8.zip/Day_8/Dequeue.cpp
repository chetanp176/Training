// Dequeue.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <deque>

using namespace std;


int main()
{
	deque <int> dq;
	dq.push_back(10);
	dq.push_back(20);
	dq.push_back(30);
	dq.push_back(15);
	cout << "The deque is : ";
	deque <int> ::iterator it;
	for (it = dq.begin(); it != dq.end(); ++it)
		cout << *it << endl;
	cout << '\n';

	return 0;
}

