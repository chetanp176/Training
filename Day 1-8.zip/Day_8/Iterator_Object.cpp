// STL_Vector.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <algorithm>
#include <vector> 

using namespace std;

class Student
{
private:
	int roll;
	char name[20];
	double percent;
public:
	Student();
	Student(int, char[], double);
	void setroll(int);
	void setname(char[]);
	void setpercent(double);
	int getroll();
	string getname();
	double getpercent();
	void toString();
	char getFirst();
	bool operator<(Student &s2){
		return this->getroll() < (int)s2.getroll();
	}
};

bool comparePercent(Student &s1, Student &s2){
	return s1.getpercent() < s2.getpercent();
}

int compareName(Student &s1, Student &s2){
	return s1.getname() < s2.getname();
}

Student::Student()
{
}

Student::Student(int r, char n[20], double p)
{
	this->roll = r;
	strcpy_s(this->name, n);
	this->percent = p;
}

void Student::setroll(int r)
{
	this->roll = r;
}

void Student::setname(char arr[20])
{
	strcpy_s(this->name, arr);
}

void Student::setpercent(double d)
{
	percent = d;
}


int Student::getroll()
{
	return roll;
}

string Student::getname()
{
	return string(name);
}

double Student::getpercent()
{
	return percent;
}

void Student::toString()
{
	cout << "Roll : " << roll << endl;
	cout << "Name : " << name << endl;
	cout << "Percentage : " << percent << endl;
}

Student ReadStudent()
{
	int roll;
	char name[20];
	double percent;
	cout << "Enter Student Roll : ";
	cin >> roll;
	cout << "Enter Student Name : ";
	cin >> name;
	cout << "Enter Student Percent : ";
	cin >> percent;
	Student S(roll, name, percent);
	return S;
}


int _tmain(int argc, _TCHAR* argv[])
{

	vector<Student> Student_Vector;
	vector<Student>::iterator ItrStud;
	/*int n = 5;
	cout << "Enter " << n << "Student objects : " << endl;
	for (int i = 0; i < n; i++)
	{
		Student ReadStud = ReadStudent();
		Student_Vector.push_back(ReadStud);
	}*/
	Student S1(5, "abc",52.5), S2(10, "agda", 56.23);
	Student_Vector.push_back(S1);
	Student_Vector.push_back(S2);

	cout << "Displaying student objects from student vector : " << endl;

	for (ItrStud = Student_Vector.begin(); ItrStud != Student_Vector.end() ; ItrStud++)
	{
		ItrStud->toString();
	}

	cout << "Sorting Student objects in the vector according to roll no : " << endl;

	sort(Student_Vector.begin(), Student_Vector.end());

	cout << "Displaying student objects after sorting : " << endl;

	for (ItrStud = Student_Vector.begin(); ItrStud != Student_Vector.end(); ItrStud++)
	{
		ItrStud->toString();
	}

	cout << "Sorting Student objects in the vector according to percent : " << endl;

	sort(Student_Vector.begin(), Student_Vector.end(), comparePercent);

	cout << "Displaying student objects after sorting : " << endl;

	for (ItrStud = Student_Vector.begin(); ItrStud != Student_Vector.end(); ItrStud++)
	{
		ItrStud->toString();
	}

	cout << "Sorting Student objects in the vector according to name : " << endl;

	sort(Student_Vector.begin(), Student_Vector.end(), compareName);

	cout << "Displaying student objects after sorting : " << endl;

	for (ItrStud = Student_Vector.begin(); ItrStud != Student_Vector.end(); ItrStud++)
	{
		ItrStud->toString();
	}

	return 0;
}