// MenuDriven.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

int add(int x, int y)
{
	return x + y;
}

int sub(int x, int y)
{
	if (x > y)
	{
		return x - y;
	}
	return y - x;
}

int mul(int x, int y)
{
	return x * y;
}

float div(float x, float y)
{
	return x / y;
}

int _tmain(int argc, _TCHAR* argv[])
{
	int i;
	cout << "1 - Addition" << endl << "2 - Subtraction" << endl << "3 - Multiplication" << endl << "4 - Division" << endl;
	cout << "Please enter your Choice :";
	cin >> i;
	int a, b;
	float c, d;
	if (i == 1 || i == 2 || i == 3)
	{
		cout << "Enter the first number" << endl;
		cin >> a;
		cout << "Enter the second number" << endl;
		cin >> b;
	}
	if (i == 4)
	{
		cout << "Enter the first number" << endl;
		cin >> c;
		cout << "Enter the second number" << endl;
		cin >> d;
	}
	switch (i)
	{
	case 1:cout << "The sum is " << add(a, b) << endl;
		break;
	case 2:cout << "The difference is " << sub(a, b) << endl;
		break;
	case 3:cout << "The product is " << mul(a, b) << endl;
		break;
	case 4:
		if (c == 0 && d == 0)
		{
			cout << "Both numbers cannot be zero" << endl;
			break;
		}
		if (d == 0)
		{
			cout << "The denominator cannot be zero" << endl;
			break;
		}
		cout << "The quotient is " << div(c,d) << endl;
		break;
	default: cout << "Invalid input" << endl;
		break;
	}
	getchar();
	return 0;
}

