// SimpleClass.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

class Student
{
private:
	int roll;
	string name;
	float percent;
public:
	void toString();
	void Setroll(int);
	void Setname(string);
	void SetPercent(float);
	float GetPercent();

};

void Student::Setroll(int r)
{
	roll = r;
}

void Student::Setname(string n)
{
	name = n;
}

void Student::SetPercent(float p)
{
	percent = p;
}

float Student::GetPercent()
{
	return percent;
}

void Student::toString()
{
	cout << "Roll : " << roll << "\nName : " << name << "\nPercentage : " << percent << endl;
}

int _tmain(int argc, _TCHAR* argv[])
{
	Student *p[3];

	int rollno;
	string sname;
	float percent;

	Student *pmax;

	for (int i = 0; i < 3; i++)
	{
		p[i] = new Student();
		cout << "Please enter the roll number" << endl;
		cin >> rollno;
		cout << "Please enter the name" << endl;
		cin >> sname;
		cout << "Please enter the percentage" << endl;
		cin >> percent;

		p[i]->Setroll(rollno);
		p[i]->Setname(sname);
		p[i]->SetPercent(percent);
	}

	pmax = p[0];

	for (int i = 1; i < 3; i++)
	{
		if (p[i]->GetPercent() > pmax->GetPercent())
		{
			pmax = p[i];
		}
	}

	cout << endl << "The student details with maximum percentage are :" << endl;

	pmax->toString();

	getchar();

	return 0;
}

