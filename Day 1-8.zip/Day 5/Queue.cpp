// Stack_Class.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

const int x = 5;

template <class T>
class Queue
{
private:
	T arr[x];
	int Front;
	int Rear;
public:
	Queue()
	{
		Front = -1;
		Rear = -1;
	}
	void Add(T n)
	{
		int i = x;
		if (Front >= i-1)
		{
			cout << "Queue is full . Cannot insert elements." << endl;
		}
		else
		{
			arr[++Front] = n;
			cout << "Inserted : " << arr[Front] << endl;
		}
	}
	void Delete()
	{
		if (Rear == Front)
		{
			cout << "Queue is empty . Cannot delete elements." << endl;
		}
		else
		{
			cout << "The popped number is : " << arr[++Rear] << endl;
		}
	}

	void Queue::display()
	{
		if (Rear == Front)
		{
			cout << "There are no elements in the stack to display " << endl;
		}
		else
		{
			cout << "The array elements are : " << endl;
			for (int i = Rear+1; i <= Front; i++)
			{
				cout << arr[i] << endl;
			}
		}
	}
};




int _tmain(int argc, _TCHAR* argv[])
{
	Queue <string> templatequeue;

	int ch = 1;
	while (ch == 1)
	{
		int choice;
		cout << "\n1 - Add \n2 - Delete \n3 - Display \n4 - Exit" << endl;
		cout << "Please enter your choice : ";
		cin >> choice;
		switch (choice)
		{
		case 1:
		{
			string var;
			cout << "Please enter the number : ";
			cin >> var;
			templatequeue.Add(var);
			break;
		}
		case 2:
		{
			templatequeue.Delete();
			break;
		}
		case 3:templatequeue.display();
			break;
		case 4:exit(0);
			break;
		default:
			break;
		}
		cout << "Do you want to Continue ?" << endl;
		cout << "Press 1 to continue or anything else to exit" << endl;
		cin >> ch;
	}
	return 0;
}

