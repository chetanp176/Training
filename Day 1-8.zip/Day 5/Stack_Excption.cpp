// Stack_Class.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

const int x = 50;

class StackFullException
{
private:
	string description;
public:
	StackFullException()
	{
		this->description = " Stack is full. Cannot insert items";
	}

	void setdescription(string s)
	{
		this->description = s;
	}

	string getdescription()
	{
		return description;
	}

};

class StackEmptyException
{
private:
	string description;
public:
	StackEmptyException()
	{
		this->description = " Stack is empty. Cannot pop items";
	}

	void setdescription(string s)
	{
		this->description = s;
	}

	string getdescription()
	{
		return description;
	}

};

template <class T>
class Stack
{
private:
	T arr[x];
	int top;
public:
	Stack()
	{
		top = -1;
	}
	void Push(T n)
	{
		if (top >= 4)
		{
			StackFullException StackFull;
			throw StackFull;
		}
		else
		{
			arr[++top] = n;
			cout << "Inserted : " << arr[top];
		}
	}
	void Pop()
	{
		if (top < 0)
		{
			StackEmptyException StackEmpty;
			throw StackEmpty;
		}
		else
		{
			cout << "Popped : " << arr[top--] << endl;
		}
	}

	void Stack::display()
	{
		if (top < 0)
		{
			StackEmptyException StackEmpty;
			throw StackEmpty;
		}
		else
		{
			cout << "The array elements are : " << endl;
			for (int i = top; i >= 0; i--)
			{
				cout << arr[i] << endl;
			}
		}
	}
};




int _tmain(int argc, _TCHAR* argv[])
{

	/*int s;
	cout << "1 - Integer\n2 - String\n3 - Float " << endl;
	cout << "What type of stack do you want to create " << endl;
	cin >> s;
	if (s == 1)
	{
	#define MYTYPE int
	}
	else if (s == 2)
	{
	}
	else if (s == 3)
	{
	#define MYTYPE float
	}
	else
	{
	cout << "Invalid Input. Exiting Program . " << endl;
	exit(0);
	}*/

#define MYTYPE int

	Stack<MYTYPE> templatestack;
	int ch = 1;
	while (ch == 1)
	{
		int choice;
		cout << "*-*-*-*-*--*-*-*-*-*" << endl;
		cout << "1 - Push \n2 - Pop \n3 - Display \n4 - Exit" << endl;
		cout << "Please enter your choice : ";
		cin >> choice;
		switch (choice)
		{
		case 1:
		{
			MYTYPE n;
			cout << "Please enter the number : ";
			cin >> n;
			try
			{
				templatestack.Push(n);
			}
			catch (StackFullException s)
			{
				cout << s.getdescription() << endl;
			}
			break;
		}
		case 2:
		{
			MYTYPE m;
			try
			{
				templatestack.Pop();
			}
			catch (StackEmptyException s)
			{
				cout << s.getdescription() << endl;
			}
			break;
		}
		case 3:try
			{
				templatestack.display();
			}
			catch (StackEmptyException s)
			{
				cout << s.getdescription() << endl;
			}
			break;
		case 4:exit(0);
			break;
		default:
			break;
		}
		cout << endl << "Do you want to Continue ?" << endl;
		cout << "Press 1 to continue or anything else to exit" << endl;
		cin >> ch;
		cout << "*-*-*-*-*--*-*-*-*-*" << endl;
	}
	return 0;
}

