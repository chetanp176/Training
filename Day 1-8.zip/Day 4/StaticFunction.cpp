// StaticFunction.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

class A
{
private:
	int i;
public:
	static int x;
	static void display()
	{
		cout << x << endl;
		//static functions can access static members
		increment();
		//static functions cannot access non-static members
		//print();
	}

	static void increment()
	{
		cout << x++ << endl;
	}

	void print()
	{
		cout << i << endl;
		//non static function can access static function
		display();
	}

	A(int i)
	{
		this->i = i;
	}

};
int A::x = 5;

int _tmain(int argc, _TCHAR* argv[])
{
	A a(10);

	//static functions can be called using class name
	A::display();

	//static functions can alsobe called using objects
	a.display();

	//non-static functions cannot be called class and always use objects
	//A::print();
	a.print();

	return 0;
}

