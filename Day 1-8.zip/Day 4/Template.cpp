// Template.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

//template<class T>
//T add(T a, T b)
//{
//	return a + b;
//}
template <class T,class T2>
T add(T a, T2 b)
{
	return a + b;
}

int _tmain(int argc, _TCHAR* argv[])
{

	//int res = add<int>(10, 20);

	//double dres = add<double>(65.5, 6.33);

	double res = add<double, int>(52.32, 10);

	cout << res << endl;

	//cout << dres << endl;

	return 0;
}

