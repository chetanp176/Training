// Object_to_File.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Student
{
private:
	int roll;
	string name;
public:
	Student();
	Student(int,string);
	void setstring(string n)
	{
		this->name = n;
	}
	string getstring()
	{
		return name;
	}
	void toString();
};

Student::Student()
{
}

Student::Student(int r, string n)
{
	this->roll = r;
	this->name = n;
	//strcpy_s(this->name, n);
}

void Student::toString()
{
	cout << "Roll : " << roll << endl;
	cout << "Name : " << name << endl;
}

void Demo()
{
	{
		Student S(51, "Chetan Patil");
		ofstream WriteF("Student_Data",ios::out|ios::binary);

		cout << "Writing Student object to file" << endl;
		cout << sizeof(S);
		WriteF.write((char *)&S, sizeof(S));

		WriteF.close();
	}

	{
		Student *R = new Student();
		{
			ifstream ReadF("Student_Data");

			cout << "Reading Student object from file" << endl;
			cout << sizeof(*R);
			ReadF.read((char *)R, sizeof(*R));
			cout << sizeof(*R);
			string s = R->getstring();
			R->setstring(s);
			ReadF.close();
			cout << "The student details taken from the file are : " << endl;

			R->toString();
		}
		delete R;
	}
}

int _tmain(int argc, _TCHAR* argv[])
{

	Demo();
	return 0;
}

