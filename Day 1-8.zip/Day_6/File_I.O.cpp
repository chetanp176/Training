// File_I.O.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

//fstream
//reading from files or writing to files

//ofstream
//writing to the file


//ifstream
//reading from the file


void writeFile(string name,string inp,int i)
{
	ofstream f(name,ios::out|ios::app);
	cout << "Appending to file " << endl;

	f << "Name : " << inp << endl;
	f << "Roll : " << i << endl;

	f.close();

}

void ReadFile(string name)
{
	ifstream readf (name,ios::in|ios::binary);

	string line;

	cout << "Reading from file " << endl;

	//while (getline(readf, line))
	//{
	//	cout << line << endl;
	//}

	//One byte (char) at a time
	char ch;
	while ( (ch=readf.get()) != -1)
	{
		cout << ch;
	}

	readf.close();

}

int _tmain(int argc, _TCHAR* argv[])
{
	string input,fname;
	int inp,choice;
	cout << "Please enter the file name you want to operate on : ";
	cin >> fname;
	cout << "1 - Write\n2 - Read" << endl;
	cout << "What do you want to do ?" << endl;
	cin >> choice;
	if (choice == 1)
	{
		cout << "Please enter the name : " << endl;
		cin.ignore();
		getline(cin, input);
		cout << "Please enter the roll : " << endl;
		cin >> inp;

		writeFile(fname, input, inp);
	}
	else if (choice == 2)
	{
		ReadFile(fname);
	}
	else
	{
		cout << "Invalid choice" << endl;
	}

	return 0;
}
